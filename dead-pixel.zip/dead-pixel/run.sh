#!/bin/bash
# Dead Pixel - one session per connection.
#
# Takes a firmware image for the emulated display adapter, boots the forensic
# workstation image with that card attached, and prints the card's register
# window when the machine stops.
set -euo pipefail

# The guest. Any distribution would do; this one is pinned so that every player
# faces an identical kernel. The challenge lives in that kernel's display driver.
: "${iso:=archlinux-2026.10.01-x86_64.iso}"
: "${iso_sha256:=684ded26c63240ff4a41e8c25ee84ea6da233f557364821f13d12c2b0a9059a5}"
if ! [ -e "${iso}" ]; then
    echo "Fetching the workstation image..."
    wget -q -O "${iso}" "https://fastly.mirror.pkgbuild.com/iso/2026.10.01/${iso}"
    if [ "$(sha256sum -- "${iso}" | cut -d" " -f1)" != "${iso_sha256}" ]; then
        echo "Image hash mismatch, discarding."
        rm -f -- "${iso}"
        exit 1
    fi
    # Drop the 15 second boot-menu delay: nobody has that kind of time.
    offset="$(grep -obUaF -m 1 'TIMEOUT 150' -- "${iso}" | cut -d: -f1)"
    if [ -n "${offset}" ]; then
        printf 'TIMEOUT 001' | dd of="${iso}" bs=1 seek="${offset}" conv=notrunc status=none
    else
        echo "Could not patch the boot timeout, discarding image."
        rm -f -- "${iso}"
        exit 1
    fi
fi

# `prepare=1 ./run.sh` only fetches the image; used at container build time.
[ -n "${prepare:-}" ] && exit 0

token="$(od -tx1 -An /dev/urandom | tr -d ' \n' | head -c16 || true)"
work="$(mktemp -d)"
: "${socket:="${work}/dp-${token}.sock"}"
: "${firmware:="${work}/fw-${token}.bin"}"
: "${staging:="${work}/fw-${token}.b64"}"
: "${budget:=240}"

function cleanup {
    kill %1 2>/dev/null || true
    rm -rf -- "${work}"
}
trap cleanup EXIT

# Greeting banner.  Printed per connection, before the prompt.
#
# NOTE: this pushes the firmware prompt past the first ~200 bytes on the wire.
# Any client that reads a fixed-size chunk and looks for "firmware" in it will
# miss the prompt -- read until you see it instead.  exploit/solve.py does.
cat <<'BANNER'

    ____                 __   ____  _           __
   / __ \___  ____ _____/ /  / __ \(_)  _____  / /
  / / / / _ \/ __ `/ __  /  / /_/ / / |/_/ _ \/ /
 / /_/ /  __/ /_/ / /_/ /  / ____/ />  </  __/ /
/_____/\___/\__,_/\__,_/  /_/   /_/_/|_|\___/_/

  evidence bay 4 -- display adapter, one stuck pixel column
  OWASP NFSU Goa Chapter CTF     authors: @thesanjok  @0xGroot
  ------------------------------------------------------------
  Policy says we re-flash every exhibit before imaging, so the
  rig takes the card's firmware from whoever runs the job.
  That is you.  The evidence disk is not your exhibit.

BANNER
echo 'Card firmware, as `gzip -c firmware.bin | base64` then a blank line:'
size=0
while IFS= read -r -t 30 line; do
    if [ -z "${line}" ]; then
        break
    fi
    echo "${line}" >> "${staging}"
    size=$((size + ${#line} + 1))
    if [ "${size}" -gt 65536 ]; then
        echo "That firmware is too large for this card."
        exit 1
    fi
done
base64 -d "${staging}" | gunzip -c > "${firmware}"

if [ "$(stat -c '%s' -- "${firmware}")" -gt 65536 ]; then
    echo "That firmware is too large for this card."
    exit 1
fi
rm -f -- "${staging}"

# Bring the card up, then hand it to the machine.
./deadpixel "${socket}" "${firmware}" | xxd -a &
for _ in $(seq 100); do
    [ -S "${socket}" ] && break
    sleep 0.05
done
if ! [ -S "${socket}" ]; then
    echo "The card did not come up."
    exit 1
fi

# From here on a failure must not stop us from showing the register window.
set +e

timeout --foreground "${budget}" qemu-system-x86_64 \
    -enable-kvm \
    -m 1536M \
    -device '{"driver":"vfio-user-pci","socket":{"path":"'"${socket}"'","type":"unix"},"x-no-posted-writes":true}' \
    -serial none -display none -monitor none -nic none -no-reboot \
    -drive if=none,id=evidence,file=flag.txt,format=raw,readonly=on \
    -device virtio-blk-pci,drive=evidence,serial=evidence \
    -cdrom "${iso}"

# Let the card finish printing its register window.
sleep 3
