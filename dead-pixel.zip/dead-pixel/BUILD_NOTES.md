# Build notes — forensic imaging rig, display adapter model

Scratch notes from getting the seized card to come up under emulation. Kept in the
tree because we will have to do this again for the next batch of exhibits.

- The card has to answer with its real identity or the workstation's driver will not
  claim it at all. Faking the identity made the driver ignore the card completely and
  we spent a day chasing that.
- Platform firmware refuses to execute an option ROM from a card in this class, which
  is why the imaging rig has to be booted all the way into the OS before the card's
  firmware is looked at by anything.
- The register window is the only thing we can read back after a run. 256 KiB, printed
  verbatim. Do not add a second channel, it makes the evidence log ambiguous.
- `dma_map`/`dma_unmap` are intentionally inert. The model must never be able to reach
  into the machine's memory; that would make anything we recover inadmissible.

## TODO

- [ ] The register window indexing was rewritten twice. Re-check the bounds maths in
      `region_write` before the next batch; an off-by-one there would be ugly.
- [ ] Decide whether the aperture should really be 256 MiB. Nothing is behind it.
- [x] Confirm the model never maps guest memory.
- [x] Pin the workstation image so every examiner sees the same software.
