Dead Pixel
==========

A challenge by @thesanjok and @0xGroot for the OWASP NFSU Goa Chapter CTF.

This is everything the service runs. `deadpixel` is the vfio-user device model for
the card, built from `src/deadpixel`; `run.sh` is what your connection talks to.

The service wants the card's firmware image, encoded as:

    gzip -c firmware.bin | base64

paste that, then a blank line. The image is capped at 64 KiB. When the machine
stops, the card prints its 256 KiB register window and you get it as a hexdump.

You can run the whole thing locally:

    docker compose build        # pulls the guest image once, ~1.6 GB
    PORT=1024 docker compose up -d
    nc 127.0.0.1 1024

The flag on your local copy is a placeholder. The real one is on the server.
