//! Minimal PCI type-0 configuration space for a vfio-user device model.
//!
//! Only what a guest actually needs in order to enumerate and use the card:
//! identity registers, the command/status pair, six base address registers and an
//! expansion ROM base address register.  Every register has an explicit writable
//! mask, so a guest can size a BAR the usual way (write all ones, read back the
//! mask) without being able to invent capabilities or change its identity.

pub const NUM_REGS: usize = 64; // 256 bytes of type-0 config space

/// Register indices (byte offset / 4).
const REG_COMMAND: usize = 1; // command (low half) + status (high half)
const REG_BAR0: usize = 4; // BAR0..BAR5 occupy registers 4..=9
const REG_ROM: usize = 12; // expansion ROM base address

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum BarKind {
    /// 32-bit non-prefetchable memory space.
    Memory32,
}

pub struct BarSpec {
    pub index: usize,
    pub size: u64,
    pub kind: BarKind,
}

pub struct PciConfig {
    regs: [u32; NUM_REGS],
    writable: [u32; NUM_REGS],
}

impl PciConfig {
    /// `class`/`subclass`/`prog_if` are the three bytes of the class code, most
    /// significant first, exactly as they appear at config offset 0x09..0x0b.
    pub fn new(vendor: u16, device: u16, class: u8, subclass: u8, prog_if: u8, revision: u8) -> Self {
        let mut regs = [0u32; NUM_REGS];
        let mut writable = [0u32; NUM_REGS];

        regs[0] = (device as u32) << 16 | vendor as u32;
        // Command starts cleared; the guest enables memory decoding itself. Only the
        // command half is writable, and only the bits a guest may legitimately set.
        regs[REG_COMMAND] = 0;
        writable[REG_COMMAND] = 0x0000_0547;
        regs[2] = (class as u32) << 24 | (subclass as u32) << 16 | (prog_if as u32) << 8 | revision as u32;
        // Header type 0, no multifunction, no BIST, cache line size writable.
        regs[3] = 0;
        writable[3] = 0x0000_00ff;
        // Interrupt line is writable, interrupt pin stays 0: this card has none.
        writable[15] = 0x0000_00ff;

        Self { regs, writable }
    }

    pub fn add_bar(&mut self, spec: &BarSpec) -> Result<(), &'static str> {
        if !spec.size.is_power_of_two() || spec.size < 16 {
            return Err("BAR size must be a power of two and at least 16 bytes");
        }
        let mask = !(spec.size as u32 - 1);
        // Low four bits of a memory BAR are the type field, read-only to the guest.
        let type_bits = match spec.kind {
            // memory space (bit0=0), 32-bit (bits2:1=00), non-prefetchable (bit3=0)
            BarKind::Memory32 => 0u32,
        };
        match spec.index {
            0..=5 => {
                let reg = REG_BAR0 + spec.index;
                self.regs[reg] = type_bits;
                self.writable[reg] = mask & 0xffff_fff0;
                Ok(())
            }
            // The ROM BAR keeps bit 0 (enable) writable alongside the address bits.
            6 => {
                let _ = type_bits; // the ROM BAR has no type field
                self.regs[REG_ROM] = 0;
                self.writable[REG_ROM] = (mask & 0xffff_f800) | 1;
                Ok(())
            }
            _ => Err("BAR index out of range"),
        }
    }

    pub fn read_reg(&self, reg: usize) -> u32 {
        self.regs.get(reg).copied().unwrap_or(0)
    }

    /// Apply a guest write of `data` at `offset` bytes into register `reg`.
    pub fn write_reg(&mut self, reg: usize, offset: u64, data: &[u8]) {
        let Some(current) = self.regs.get(reg).copied() else {
            return;
        };
        let offset = offset as usize;
        if offset + data.len() > 4 {
            return;
        }
        let mut bytes = current.to_le_bytes();
        bytes[offset..offset + data.len()].copy_from_slice(data);
        let proposed = u32::from_le_bytes(bytes);
        let mask = self.writable[reg];
        self.regs[reg] = (current & !mask) | (proposed & mask);
    }
}
