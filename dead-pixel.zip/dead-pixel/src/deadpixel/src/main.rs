//! Dead Pixel — vfio-user device model for an OWASP NFSU CTF challenge.
//!
//! Written by @thesanjok for the OWASP NFSU Goa Chapter CTF.
//!
//! Emulates the display adapter out of a seized forensic workstation. The card is
//! faithful enough that the guest's own display driver binds to it, and the *player*
//! supplies its expansion ROM, i.e. the video firmware the driver is about to parse.
//!
//! What the guest can see and do:
//!   * BAR0  — 256 MiB framebuffer aperture. Reads return zero, writes are discarded.
//!             The card has no real memory behind it; the aperture only exists so the
//!             driver's memory-controller setup looks plausible.
//!   * BAR2  — 256 KiB register window, readable and writable, backed by a plain
//!             array. Whatever is left in it when the machine stops is printed on
//!             stdout: this is the only channel out of the guest.
//!   * ROM   — read-only, serves the player-supplied image.
//!
//! The model is deliberately boring: every access is bounds-checked, the device never
//! maps or touches guest memory (`dma_map`/`dma_unmap` are no-ops), and it exposes no
//! interrupts. There is no memory-safety bug to find in here.

use std::io::{ErrorKind, Write};
use std::path::PathBuf;

use clap::Parser;
use vfio_bindings::bindings::vfio::{
    VFIO_PCI_BAR0_REGION_INDEX, VFIO_PCI_BAR2_REGION_INDEX, VFIO_PCI_CONFIG_REGION_INDEX,
    VFIO_PCI_NUM_IRQS, VFIO_PCI_NUM_REGIONS, VFIO_PCI_ROM_REGION_INDEX, VFIO_REGION_INFO_FLAG_READ,
    VFIO_REGION_INFO_FLAG_WRITE, vfio_region_info,
};
use vfio_user::{IrqInfo, Server, ServerBackend, ServerRegion};

mod pci;

/// A real Tahiti-class part. The identity has to be genuine or the guest driver
/// would not claim the card at all.
const VENDOR_ID: u16 = 0x1002;
const DEVICE_ID: u16 = 0x6780;
/// Display controller / "other" rather than VGA. Firmware will not run an option ROM
/// from a device in this class, so the firmware image only ever reaches the OS driver.
const CLASS_DISPLAY: u8 = 0x03;
const SUBCLASS_OTHER: u8 = 0x80;

const BAR0_SIZE: usize = 0x1000_0000; // 256 MiB aperture
const BAR2_SIZE: usize = 0x0004_0000; // 256 KiB of registers
const REG_COUNT: usize = BAR2_SIZE / 4;

#[derive(Parser)]
#[command(about = "vfio-user model of a seized forensic display adapter")]
struct Cli {
    /// UNIX socket to serve the device on
    socket: PathBuf,
    /// expansion ROM image to hand to the guest
    rom: PathBuf,
}

struct Card {
    cfg: pci::PciConfig,
    regs: [u32; REG_COUNT],
    rom: Vec<u8>,
}

impl Card {
    /// A PCI expansion ROM BAR is a power of two and at least 2 KiB.
    fn rom_window(rom: &[u8]) -> u64 {
        rom.len().max(2048).next_power_of_two() as u64
    }

    fn new(rom: Vec<u8>) -> Self {
        let mut cfg = pci::PciConfig::new(
            VENDOR_ID,
            DEVICE_ID,
            CLASS_DISPLAY,
            SUBCLASS_OTHER,
            0x00,
            0x00,
        );
        for spec in [
            pci::BarSpec { index: 0, size: BAR0_SIZE as u64, kind: pci::BarKind::Memory32 },
            pci::BarSpec { index: 2, size: BAR2_SIZE as u64, kind: pci::BarKind::Memory32 },
            pci::BarSpec { index: 6, size: Self::rom_window(&rom), kind: pci::BarKind::Memory32 },
        ] {
            cfg.add_bar(&spec).expect("invalid PCI BAR layout");
        }
        Self { cfg, regs: [0u32; REG_COUNT], rom }
    }

    /// Print the register window. Called once, after the machine has stopped.
    fn dump(&self) {
        let mut out = Vec::with_capacity(BAR2_SIZE);
        for value in self.regs {
            out.extend_from_slice(&value.to_le_bytes());
        }
        let mut stdout = std::io::stdout().lock();
        stdout.write_all(&out).expect("failed to dump register window");
        stdout.flush().expect("failed to flush register window");
    }
}

/// Describe every region the client may ask about. Anything not listed below is
/// reported as zero-sized and rejects access.
fn regions(card: &Card) -> Vec<ServerRegion> {
    (0..VFIO_PCI_NUM_REGIONS)
        .map(|index| {
            let mut region = vfio_region_info {
                argsz: std::mem::size_of::<vfio_region_info>() as u32,
                index,
                ..Default::default()
            };
            match index {
                VFIO_PCI_CONFIG_REGION_INDEX => {
                    region.size = (pci::NUM_REGS * 4) as u64;
                    region.flags = VFIO_REGION_INFO_FLAG_READ | VFIO_REGION_INFO_FLAG_WRITE;
                }
                VFIO_PCI_BAR0_REGION_INDEX => {
                    region.size = BAR0_SIZE as u64;
                    region.flags = VFIO_REGION_INFO_FLAG_READ | VFIO_REGION_INFO_FLAG_WRITE;
                }
                VFIO_PCI_BAR2_REGION_INDEX => {
                    region.size = BAR2_SIZE as u64;
                    region.flags = VFIO_REGION_INFO_FLAG_READ | VFIO_REGION_INFO_FLAG_WRITE;
                }
                VFIO_PCI_ROM_REGION_INDEX => {
                    region.size = Card::rom_window(&card.rom);
                    region.flags = VFIO_REGION_INFO_FLAG_READ;
                }
                _ => {}
            }
            ServerRegion { region_info: region, sparse_areas: Vec::new(), mmap_fd: None }
        })
        .collect()
}

/// This card has no MSI, no MSI-X and no interrupt pin.
fn irqs() -> Vec<IrqInfo> {
    (0..VFIO_PCI_NUM_IRQS)
        .map(|index| IrqInfo { index, count: 0, flags: 0 })
        .collect()
}

impl ServerBackend for Card {
    fn region_read(&mut self, region: u32, offset: u64, data: &mut [u8]) -> Result<(), std::io::Error> {
        let len = data.len();
        if region == VFIO_PCI_CONFIG_REGION_INDEX {
            // Clients are allowed to slurp the whole config space in one request, so
            // serve it register by register rather than assuming a single access.
            if len > 4 {
                if !len.is_multiple_of(4) || !offset.is_multiple_of(4) {
                    return Err(ErrorKind::InvalidInput.into());
                }
                let mut reg = offset as usize / 4;
                for chunk in data.chunks_mut(4) {
                    chunk.copy_from_slice(&self.cfg.read_reg(reg).to_le_bytes());
                    reg += 1;
                }
            } else {
                let within = offset as usize % 4;
                if within + len > 4 || !within.is_multiple_of(len) {
                    return Err(ErrorKind::InvalidInput.into());
                }
                let value = self.cfg.read_reg(offset as usize / 4).to_le_bytes();
                data.copy_from_slice(&value[within..within + len]);
            }
            Ok(())
        } else if region == VFIO_PCI_BAR0_REGION_INDEX {
            // No memory behind the aperture.
            data.fill(0);
            Ok(())
        } else if region == VFIO_PCI_BAR2_REGION_INDEX {
            let index = offset as usize / 4;
            if len != 4 || !offset.is_multiple_of(4) || index >= self.regs.len() {
                tracing::warn!("rejected {len:#x}-byte register read at {offset:#x}");
                data.fill(0);
                return Ok(());
            }
            let value = self.regs[index];
            tracing::debug!("read  reg[{index:#06x}] = {value:#010x}");
            data.copy_from_slice(&value.to_le_bytes());
            Ok(())
        } else if region == VFIO_PCI_ROM_REGION_INDEX {
            // Serve the image and zero-pad the rest of the window.
            let begin = (offset as usize).min(self.rom.len());
            let end = begin.saturating_add(len).min(self.rom.len());
            let copied = len.min(end - begin);
            data[..copied].copy_from_slice(&self.rom[begin..end]);
            data[copied..].fill(0);
            Ok(())
        } else {
            tracing::warn!("rejected read from region {region} at {offset:#x}");
            data.fill(0);
            Ok(())
        }
    }

    fn region_write(&mut self, region: u32, offset: u64, data: &[u8]) -> Result<(), std::io::Error> {
        if region == VFIO_PCI_CONFIG_REGION_INDEX {
            self.cfg.write_reg(offset as usize / 4, offset % 4, data);
            Ok(())
        } else if region == VFIO_PCI_BAR0_REGION_INDEX {
            // Writes into the aperture go nowhere.
            Ok(())
        } else if region == VFIO_PCI_BAR2_REGION_INDEX {
            let index = offset as usize / 4;
            let Ok(value) = data.try_into().map(u32::from_le_bytes) else {
                tracing::warn!("rejected {:#x}-byte register write at {offset:#x}", data.len());
                return Ok(());
            };
            if !offset.is_multiple_of(4) || index >= self.regs.len() {
                tracing::warn!("rejected misaligned/out-of-range register write at {offset:#x}");
                return Ok(());
            }
            tracing::debug!("write reg[{index:#06x}] = {value:#010x}");
            self.regs[index] = value;
            Ok(())
        } else {
            tracing::warn!("rejected write to region {region} at {offset:#x}");
            Ok(())
        }
    }

    fn dma_map(
        &mut self,
        _flags: vfio_user::DmaMapFlags,
        _offset: u64,
        _address: u64,
        _size: u64,
        _fd: Option<std::fs::File>,
    ) -> Result<(), std::io::Error> {
        // The card never reads or writes guest memory.
        Ok(())
    }

    fn dma_unmap(
        &mut self,
        _flags: vfio_user::DmaUnmapFlags,
        _address: u64,
        _size: u64,
    ) -> Result<(), std::io::Error> {
        Ok(())
    }

    fn reset(&mut self) -> Result<(), std::io::Error> {
        self.regs.fill(0);
        Ok(())
    }

    fn set_irqs(
        &mut self,
        _index: u32,
        _flags: u32,
        _start: u32,
        _count: u32,
        _fds: Vec<std::fs::File>,
    ) -> Result<(), std::io::Error> {
        Ok(())
    }
}

fn main() {
    tracing_subscriber::fmt()
        .with_writer(std::io::stderr)
        .with_max_level(tracing::Level::DEBUG)
        .init();
    let args = Cli::parse();
    let rom = std::fs::read(&args.rom).expect("failed to read the ROM image");

    let mut card = Card::new(rom);
    let server = Server::new(&args.socket, true, irqs(), regions(&card))
        .expect("failed to create the vfio-user server");
    let result = server.run(&mut card);
    card.dump();
    result.expect("device server exited with an error");
}
